import testFileUtils from './utils/fileUtils.test.js'

function main() {
    console.log('Test Suite')
    console.log()
    testFileUtils.runAll()
}

main()
