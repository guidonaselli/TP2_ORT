import fu from '../../src/utils/fileUtils.js'

/**
 * a quien estoy testeando
 *
 * descripcion del test
*/
function test01() {

    console.log('test 1:')

}


function runAll() {
    console.log('Testing fileUtils:')
    test01()
}

export default {
    runAll
}