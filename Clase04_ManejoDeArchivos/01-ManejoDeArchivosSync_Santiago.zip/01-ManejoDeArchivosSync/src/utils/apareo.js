/**
 * toma dos arrays de números ordenados y en forma eficiente los combina en uno solo, aún ordenado
 * @param {number[]} arrA un array de números ordenados
 * @param {number[]} arrB otro array de números ordenados
 * @returns {number[]} un nuevo array de números ordenados
 */
function combinarDosArrays(arrA, arrB) {
    return arrA.concat(arrB);
}

/**
 * toma un array de muchos arrays de números ordenados y los combina en uno solo, aún ordenado
 * @param {number[][]} arrs el array de arrays de números que quiero combinar
 * @returns {number[]} el nuevo array de números ordenados
 */
function combinarNArrays(arrs) {
    let out = [];
    arrs.forEach(e => {
        out = out.concat(e);
    });
    return out;
}


// exportar lo necesario
module.exports = {
    combinarDosArrays: combinarDosArrays,
    combinarNArrays: combinarNArrays
};