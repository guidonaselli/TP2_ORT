// importar lo necesario
const fs = require('fs');
/**
 * lee y devuelve el contenido de un archivo como texto en 'utf-8'
 * @param {string} ruta
 * @return {string} el texto leído
 */
function leerArchivoComoString(ruta) {
    //Verifico que exista el archivo
    if (fs.existsSync(ruta)) {
        //Leo el archivo JSON
        return fs.readFileSync(ruta, {encoding:'utf8', flag:'r'});


        /* 
        //Version asincronica (No utilizada porque necesito retornar el resultado)
        
        fs.readFile(ruta, 'utf-8', (err, data) => {
            if (err) {
            console.error(err);
            return;
            }

            return data;
        });
        */
    }
    return null;
}

/**
 * escribe el texto en el archivo de la ruta, sólo si tal archivo existe. sino, lanza error.
 * @param {string} ruta
 * @param {string} texto
 */
function escribirTextoEnArchivo(ruta, texto, shouldCreateIfNotExists) {
}

// exportar lo necesario
module.exports = {
    leerArchivoComoString: leerArchivoComoString,
    escribirTextoEnArchivo: escribirTextoEnArchivo
};