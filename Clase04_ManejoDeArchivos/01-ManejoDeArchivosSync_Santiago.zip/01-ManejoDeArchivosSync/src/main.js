const fs = require('fs');
const ap = require('./utils/apareo.js');
const fu = require('./utils/fileUtils.js');
const tu = require('./utils/transformUtils.js');

const PATH = '../in/';
const FILES = [
                PATH + '10NumerosOrdenadosEntre1y50(setA).in',
                PATH + '10NumerosOrdenadosEntre1y50(setB).in',
                PATH + 'imparesOrdenadosEntre1y999.in',
                PATH + 'paresOrdenadosEntre2y1000.in'
              ]


// cargos todos los archivos en memoria

for (let i = 0; i < FILES.length; i++) {
  const data = fu.leerArchivoComoString(FILES[i]);
  const numbers = tu.transformarStringEnArrayDeNumeros(data, ',');
  
  //console.log(numbers);
}


// preparo 4 arrays para aparear

const arrays = [[], [], [], []];

for (let i = 0; i < FILES.length; i++) {
  const data = fu.leerArchivoComoString(FILES[i]);
  const numbers = tu.transformarStringEnArrayDeNumeros(data, ',');
  
  arrays[i] = numbers;
}

/* 
//Imprimir los 4 arrays

for (let i = 0; i < arrays.length; i++) {
  for (let j = 0; j < arrays[i].length; j++) {
    console.log(arrays[i][j]);
  }
  console.log('\n');
}
*/


// apareo simple

console.log('===================================================================');
console.log('APAREO SIMPLE');
console.log('===================================================================');
console.log(ap.combinarDosArrays(arrays[0], arrays[1]));


// armo un array con los 4 arrays que quiero aparear

//Ya hecho como un array de arrays desde el inicio


// apareo múltiple

console.log('===================================================================');
console.log('APAREO MULTIPLE');
console.log('===================================================================');
console.log(ap.combinarNArrays(arrays));